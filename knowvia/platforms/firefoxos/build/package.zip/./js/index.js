/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
        //connect to server

        //load returned json into array
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        var options = { timeout: 30000, enableHighAccuracy: true };
        watchID = navigator.geolocation.watchPosition(onSuccess, onError, options);
        var watch = document.getElementById('wid');
        watch.innerHTML = watchID;
        app.receivedEvent('deviceready');
    },

    function onSuccess(position) {
        /*var lat = document.getElementById('lat');
        var lon = document.getElementById('lon');
        var hdng = document.getElementById('hdng');

        lat.innerHTML = positions.coords.latitude;
        lon.innerHTML = positions.coords.longitude;
        hdng.innerHTML = positions.coords.heading;*/

        //don't need to store it, can just do teh call right here

        //after call, update the canvas form here, too.

        //shoudl keep an array of teh current points in memory,
        //and when the returned array is different that's when
        //it is known that an arrow should be added and/or removed

        //use heading to know how much to rotate the canvas
    },

    // Show an alert if there is a problem getting the geolocation
    //
    function onError(error) {
        alert('code: '    + error.code    + '\n' +
              'message: ' + error.message + '\n');
    },


    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        //var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        //receivedElement.setAttribute('style', 'display:block;');

        $(".app").css("background", "");

        //initialize canvas
        //change background image to none

        //arrows: ./img/512/navigate.png OR arrow-up-a.png

        //centre: ./img/512/happy.png OR earth.png

        //display arrows with text pointing to nearby things

        //start navigator.geolocation.watchPosition

        console.log('Received Event: ' + id);
    }
};
